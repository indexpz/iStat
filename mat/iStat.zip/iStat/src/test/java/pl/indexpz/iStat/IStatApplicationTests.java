package pl.indexpz.iStat;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IStatApplicationTests {

	@Test
	void contextLoads() {
	}

}
