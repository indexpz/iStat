package pl.indexpz.iStat;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IStatApplication {

	public static void main(String[] args) {
		SpringApplication.run(IStatApplication.class, args);
	}

}
